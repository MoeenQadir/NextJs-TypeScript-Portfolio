import Ember from 'ember';

export default Ember.Object.create({
    content: ['left', 'center', 'right']
});
