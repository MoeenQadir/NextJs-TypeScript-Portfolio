import DS from 'ember-data';

export default DS.Model.extend({
    name: DS.attr('string'),
    value: DS.attr('string'),
    active: DS.attr('boolean', { defaultValue: true }),
    prompted: DS.attr('boolean')
});
