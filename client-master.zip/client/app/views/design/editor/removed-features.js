import Ember from 'ember';

export default Ember.View.extend({
    templateName: 'design/editor/removed_features',
    tagName: 'li',
    classNames: ['removedFeatures']
});
