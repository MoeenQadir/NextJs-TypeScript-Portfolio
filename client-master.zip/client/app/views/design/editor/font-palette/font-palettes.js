import Ember from 'ember';

export default Ember.View.extend({
    templateName: 'design/editor/font_palettes_view'
});
