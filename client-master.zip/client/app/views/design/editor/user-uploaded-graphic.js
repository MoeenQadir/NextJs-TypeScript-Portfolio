import Ember from 'ember';

export default Ember.View.extend({
    templateName: 'design/editor/user_uploaded_graphic'
});
