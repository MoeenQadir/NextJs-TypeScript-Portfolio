import Ember from 'ember';

export default Ember.View.extend({
    layoutName: 'design/editor/slider_layout'
});
