import Ember from 'ember';

export default Ember.View.extend({
    templateName: 'design/editor/category_dropdown',
    classNames: ['dropdown'],
    menuOpenByDefault: true
});
