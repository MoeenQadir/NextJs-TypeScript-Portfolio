import Ember from 'ember';

export default Ember.View.extend({
    templateName: 'design/editor/category_dropdown_menu_item',
    classNames: ['dropdown-menu-item'],
    tagName: 'li'
});
