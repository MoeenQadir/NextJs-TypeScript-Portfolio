export function islast(array, index) {
    return array.length === (index + 1);
}

export default islast;
