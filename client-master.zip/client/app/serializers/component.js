import ApplicationSerializer from './application';
import SerializerMixin from '../mixins/serializer';

export default ApplicationSerializer.extend(SerializerMixin, {
});

