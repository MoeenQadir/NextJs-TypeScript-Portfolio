import ApplicationAdapter from './application';
import DummyAdapterMixin from '../mixins/dummy-adapter';

export default ApplicationAdapter.extend(DummyAdapterMixin);


