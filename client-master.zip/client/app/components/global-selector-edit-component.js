import GlobalSelectorEdit from './global-selector-edit';

export default GlobalSelectorEdit.extend({
    layoutName: 'global-selector-edit-component'
});
