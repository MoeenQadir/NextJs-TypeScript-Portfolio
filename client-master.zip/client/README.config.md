This file provides structure of available configuration options:
```json
{
  "zendesk": {
    "key": ""
  }
}
```
